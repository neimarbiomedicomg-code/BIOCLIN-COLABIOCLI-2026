/**
 * Catálogo digital Bioclin – COLABIOCLI 2026 – VERSÃO 2 (envio direto)
 *
 * O que faz, a cada lista enviada pelo catálogo:
 *  1. grava uma linha na planilha (aba "Leads"), com feira, vendedor, origem do QR, idioma e score;
 *  2. envia ao visitante um e-mail de agradecimento com o PDF de cada linha marcada e o link do catálogo;
 *  3. avisa o responsável Bioclin com o resumo do lead.
 *
 * Como instalar (uma vez):
 *  - Crie uma planilha Google nova, por exemplo "Leads COLABIOCLI 2026".
 *  - Menu Extensões > Apps Script. Apague o que estiver lá e cole este arquivo inteiro. Salve.
 *  - Implantar > Nova implantação > tipo "App da Web".
 *      Executar como: Eu  |  Quem pode acessar: Qualquer pessoa
 *  - Autorize com a sua conta Google e copie a URL que termina em /exec.
 *  - Mande essa URL para o Claude (ou cole no catálogo: modo administrador > Ajustes > "Envio direto").
 */

const CONFIG = {
  AVISAR: 'neimar.barbosa@bioclin.com.br',   // quem recebe o aviso de cada lead
  RESPONDER_PARA: 'neimar.barbosa@bioclin.com.br', // quando o visitante responder, vai para este e-mail
  REMETENTE: 'Bioclin · COLABIOCLI 2026',
  ASSINATURA: 'Neimar Barbosa<br>Bioclin – Diagnóstico para un mundo más saludable',
  ABA: 'Leads'
};

const TXT = {
  es: { assunto: 'Su catálogo Bioclin – COLABIOCLI 2026',
        ola: '¡Gracias por visitar el stand de Bioclin en COLABIOCLI 2026!',
        recebemos: 'Recibimos su lista de interés. Nuestro equipo la revisará y le responderá en hasta 2 días hábiles.',
        pdfs: 'Catálogos de las líneas que usted marcó:', produtos: 'Productos seleccionados:',
        cat: 'Consulte el catálogo digital completo cuando quiera:', abrir: 'Abrir catálogo digital', att: 'Saludos cordiales,' },
  pt: { assunto: 'Seu catálogo Bioclin – COLABIOCLI 2026',
        ola: 'Obrigado pela visita ao estande da Bioclin no COLABIOCLI 2026!',
        recebemos: 'Recebemos sua lista de interesse. Nossa equipe vai analisar e responder em até 2 dias úteis.',
        pdfs: 'Catálogos das linhas que você marcou:', produtos: 'Produtos selecionados:',
        cat: 'Consulte o catálogo digital completo quando quiser:', abrir: 'Abrir catálogo digital', att: 'Atenciosamente,' },
  en: { assunto: 'Your Bioclin catalogue – COLABIOCLI 2026',
        ola: 'Thank you for visiting the Bioclin booth at COLABIOCLI 2026!',
        recebemos: 'We received your list of interest. Our team will review it and reply within 2 business days.',
        pdfs: 'Catalogues of the lines you selected:', produtos: 'Selected products:',
        cat: 'Browse the full digital catalogue anytime:', abrir: 'Open digital catalogue', att: 'Best regards,' }
};

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents || '{}');
    const email = String(d.email || '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return out_({ ok: false, erro: 'email' });

    const lock = LockService.getScriptLock(); lock.waitLock(20000);
    try { grava_(d); } finally { lock.releaseLock(); }

    enviaVisitante_(d);
    avisaBioclin_(d);
    return out_({ ok: true });
  } catch (err) {
    return out_({ ok: false, erro: String(err) });
  }
}

function doGet() { return out_({ ok: true, info: 'Catálogo Bioclin V2 ativo' }); }

function grava_(d) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(CONFIG.ABA);
  if (!sh) {
    sh = ss.insertSheet(CONFIG.ABA);
    sh.appendRow(['Data/hora', 'Score', 'Instituição', 'E-mail', 'Tipo', 'País', 'Linhas de interesse', 'Produtos', 'Idioma', 'Feira', 'Vendedor', 'Origem do QR', 'Modo', 'Responsável', 'Status', 'Notas']);
    sh.setFrozenRows(1);
  }
  const linhas = (d.linhas || []).map(x => x.nome + (x.completa ? ' (linha completa)' : '')).join('; ');
  const prods = (d.produtos || []).map(p => (p.code ? p.code + ' · ' : '') + p.nome).join('; ');
  sh.appendRow([new Date(), String(d.score || '').toUpperCase(), d.empresa, d.email, d.perfil_txt || d.perfil, d.pais,
                linhas, prods, d.lang, d.feira, d.vend, d.origem, d.modo, '', 'Novo', '']);
}

function enviaVisitante_(d) {
  const L = TXT[d.lang] || TXT.es;
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pdfs = (d.linhas || []).map(x => `<li><a href="${esc(x.pdf)}">${esc(x.nome)}</a></li>`).join('');
  const prods = (d.produtos || []).slice(0, 40).map(p => `<li>${p.code ? esc(p.code) + ' · ' : ''}${esc(p.nome)}</li>`).join('');
  const html = `
  <div style="font-family:Arial,Helvetica,sans-serif;color:#18264a;font-size:15px;line-height:1.5;max-width:560px">
    <p style="font-size:18px"><b>${L.ola}</b></p>
    <p>${L.recebemos}</p>
    ${pdfs ? `<p><b>${L.pdfs}</b></p><ul>${pdfs}</ul>` : ''}
    ${prods ? `<p><b>${L.produtos}</b></p><ul style="color:#5b6b84">${prods}</ul>` : ''}
    <p>${L.cat}</p>
    <p><a href="${esc(d.catalogo)}" style="display:inline-block;background:#22366a;color:#fff;text-decoration:none;padding:12px 20px;border-radius:10px;font-weight:bold">${L.abrir}</a></p>
    <p>${L.att}<br>${CONFIG.ASSINATURA}</p>
  </div>`;
  MailApp.sendEmail({ to: d.email, replyTo: CONFIG.RESPONDER_PARA, name: CONFIG.REMETENTE, subject: L.assunto, htmlBody: html });
}

function avisaBioclin_(d) {
  const linhas = (d.linhas || []).map(x => '- ' + x.nome + (x.completa ? ' (linha completa)' : '')).join('\n');
  const prods = (d.produtos || []).map(p => '- ' + (p.code ? p.code + ' · ' : '') + p.nome).join('\n');
  const corpo = [
    'Novo lead do catálogo digital (' + String(d.score || '').toUpperCase() + ')',
    '',
    'Instituição: ' + d.empresa, 'E-mail: ' + d.email, 'Tipo: ' + (d.perfil_txt || d.perfil), 'País: ' + d.pais,
    'Idioma: ' + d.lang + ' | Feira: ' + d.feira + ' | Vendedor: ' + (d.vend || '-') + ' | Origem: ' + d.origem + ' | Modo: ' + d.modo,
    '', 'Linhas de interesse:', linhas || '-', '', 'Produtos:', prods || '-',
    '', 'Planilha: ' + SpreadsheetApp.getActiveSpreadsheet().getUrl()
  ].join('\n');
  // assunto SEM "[Catálogo Bioclin]" para não acionar a resposta automática do Outlook
  MailApp.sendEmail({ to: CONFIG.AVISAR, replyTo: d.email, name: 'Catálogo Bioclin',
                      subject: '[Lead feira] ' + String(d.score || '').toUpperCase() + ' – ' + d.empresa + ' – ' + d.pais, body: corpo });
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Teste rápido: rode esta função no editor (botão Executar) para gravar um lead de exemplo e receber os dois e-mails. */
function testeManual() {
  const eu = Session.getActiveUser().getEmail();
  doPost({ postData: { contents: JSON.stringify({
    lang: 'es', modo: 'teste', feira: 'COLABIOCLI 2026', vend: 'teste', origem: 'capa',
    empresa: 'Laboratorio Teste', email: eu, perfil: 'lab', perfil_txt: 'Laboratorio clínico', pais: 'Bolivia', score: 'morno',
    linhas: [{ nome: 'Bioquímica · División Humana', completa: true, pdf: 'https://neimarbiomedicomg-code.github.io/BIOCLIN-COLABIOCLI-2026/pdf/bioclin-hum-bioq-es.pdf' }],
    produtos: [{ code: 'K122-1', nome: 'Citomegalovirus IgG', linha: 'ELISA' }],
    catalogo: 'https://neimarbiomedicomg-code.github.io/BIOCLIN-COLABIOCLI-2026/?modo=cliente'
  }) } });
}
